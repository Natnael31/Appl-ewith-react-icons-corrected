function Abebe () {
    return (
        <div>
            Abebe beso bela

        </div>
    );
}

export default Abebe;